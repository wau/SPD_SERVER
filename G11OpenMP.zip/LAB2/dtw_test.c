#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <omp.h>
#define infinity INFINITY //
int main(int argc, char*argv[]) {
   FILE *fp;
   double *s;
   double *t;
   int n=atoi(argv[1]);
   int m=atoi(argv[2]);
   fp = fopen("array1.txt","r");
   s =(double*) malloc (n*sizeof(double));
   for(int i=0;i<n;i++){
   if(fscanf(fp,"%lf",&s[i]) != 1){
   return 1;
   }
 }
 fclose(fp);

 fp = fopen("array2.txt","r");
 t = (double*) malloc (m*sizeof(double));
 for(int i=0;i<m;i++){
 if(fscanf(fp,"%lf",&t[i]) != 1){
 return 1;
 }
 }
 fclose(fp);
 int nthreads,id;
 double start,end,cost,min,min1;
 int i,j;
double *DTW = malloc((n+1)*(m+1) *sizeof(double));

 // inicializando a primeira coluna e primeira linha com

 for (i = 1; i <= n; i++)
 DTW[i*(m+1)] = infinity;
 for (j = 1; j <= m; j++)
 DTW[j] = infinity;
 DTW[0] = 0;

 omp_set_num_threads(8);
 #pragma omp parallel
 {
 #pragma omp master
 {
 nthreads = omp_get_num_threads();
 printf("Running with %d threads\n",nthreads);
 }

 // preenchendo a matriz DTW
 start = omp_get_wtime();
 #pragma omp for ordered private(i,j)
 for (i = 1; i <= n; i++)
 #pragma omp ordered
 for (j = 1; j <= m; j++) {
 float cost = s[i-1] - t[j-1];
 if (cost < 0) cost *= -1;
 double coord1 = DTW[i*(m+1)+(j-1)];
 double coord2 = DTW[(i-1)*(m+1)+(j-1)];
 double coord3 = DTW[(i-1)*(m+1) + j];
 min = coord1 < coord2 ? coord1 : coord2;
 min1 = coord3 < min ? coord3 : min;
 DTW[i*(m+1)+j] = cost + min1 ;
 }
 }
 end = omp_get_wtime();
 printf("%lf \n", end-start);
 printf("%lf :\n", DTW[n*(m+1)+m]);
 free(s);
 free(t);
 free(DTW);
 return 0;
}